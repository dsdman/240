#include <iostream>
using namespace std;

/****************************************************************
 * Main program for Homework 1.
 *
 * Author/copyright:  Duncan Buell. All rights reserved.
 * Date: 14 May 2016
 * Modified by Dylan Desai on Aug 29 for Homework 1 assignment
**/

int main(int argc, char *argv[]) {
  cout << "Hello,[sic] world." << endl;
  cout << "My name is Dylan Desai." << endl;

  return 0;
}
